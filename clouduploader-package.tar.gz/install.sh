#!/bin/bash

# Installation script for clouduploader

# Define installation directory
INSTALL_DIR="/usr/local/bin"

# Copy the script to the installation directory
cp clouduploader "$INSTALL_DIR"

# Provide executable permissions
chmod +x "$INSTALL_DIR/clouduploader"

echo "clouduploader has been installed to $INSTALL_DIR"
