# clouduploader

## Installation

1. Download the clouduploader package.
2. Navigate to the package directory.
3. Run the installation script:

   ```bash
   sudo ./install.sh
